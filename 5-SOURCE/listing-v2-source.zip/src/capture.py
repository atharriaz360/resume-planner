from playwright.sync_api import sync_playwright
import pathlib,datetime
u=pathlib.Path('app.html').resolve().as_uri()
CSS='.banner{display:none!important}#toast{display:none!important}'
def setup(pg):
  pg.clock.install(time=datetime.datetime(2026,10,27,9,41))
  pg.goto(u+'#settings');pg.wait_for_timeout(500)
  pg.click('[data-act="sample"]');pg.wait_for_timeout(400)
def go(pg,r):
  pg.goto(u+'#'+r);pg.wait_for_timeout(600);pg.add_style_tag(content=CSS);pg.wait_for_timeout(200)
with sync_playwright() as p:
  b=p.chromium.launch()
  ctx_to=5000
  # desktop 16:10 at MacBook ratio (1512x982 ~ MBP 14 screen 3024x1964)
  pg=b.new_page(viewport={'width':1512,'height':982},device_scale_factor=2);pg.set_default_timeout(5000)
  setup(pg)
  # resume paper variants
  go(pg,'resume')
  for t in ['mint','executive','sidebar']:
    for a in ['mint','ocean','amber']:
      try:
        pg.evaluate(f"S.resume.template='{t}';S.resume.accent='{a}';save();render()");pg.wait_for_timeout(400)
        pg.locator('#paper').screenshot(path=f'cap/p-{t}-{a}.png')
      except Exception as e: print('err',t,a,e)
  # phone
  ph=b.new_page(viewport={'width':393,'height':852},device_scale_factor=3,is_mobile=True,has_touch=True)
  setup(ph)
  for r in ['hub','resume','cover','jobs','bank']:
    go(ph,r);ph.screenshot(path=f'cap/m-{r}.png')
  # tablet
  tb=b.new_page(viewport={'width':1180,'height':820},device_scale_factor=2,has_touch=True)
  setup(tb)
  for r in ['hub','resume','jobs']:
    go(tb,r);tb.screenshot(path=f'cap/t-{r}.png')
  b.close()
