import cv2,numpy as np,comp
def load(n):return cv2.imread(comp.B+n+'.jpg')
# 21: tracker
bg=load('21');big,S=comp.upscale(bg)
big,qs=comp.screens_into(big,bg,S,['cap/d-jobs.png'])
big=comp.paper_into(big,bg,S,[[266,975],[605,907],[980,1052],[604,1153]],'cap/q-executive-ocean.png',thr=(170,40),ymin=880)
cv2.imwrite('scenes/s21-jobs.png',big)
# 20: laptop hub + phone tracker
bg=load('20');big,S=comp.upscale(bg,seed=3)
big,qs=comp.screens_into(big,bg,S,['cap/d-hub.png','cap/ms-jobs.png'])
cv2.imwrite('scenes/s20-hub.png',big)
# 22: laptop resume + phone hub (hand)
bg=load('22');big,S=comp.upscale(bg,seed=5)
big,qs=comp.screens_into(big,bg,S,['cap/d-hub.png','cap/ms-hub.png'],bright=0.95)
cv2.imwrite('scenes/s22-hub.png',big)
# 19: cover letter on paper
bg=load('19');big,S=comp.upscale(bg,seed=9)
big=comp.paper_into(big,bg,S,[[230,1003],[650,941],[1094,1115],[654,1235]],'cap/q-cover.png',thr=(170,40),ymin=900,bright=1.0,ink_floor=0.0)
cv2.imwrite('scenes/s19-cover.png',big)
print('ok')
