from playwright.sync_api import sync_playwright
import pathlib,datetime
u=pathlib.Path('app.html').resolve().as_uri()
with sync_playwright() as p:
  b=p.chromium.launch();pg=b.new_page(viewport={'width':1512,'height':982},device_scale_factor=2);pg.set_default_timeout(5000)
  pg.clock.install(time=datetime.datetime(2026,10,27,9,41))
  pg.goto(u+'#settings');pg.wait_for_timeout(400);pg.click('[data-act="sample"]');pg.wait_for_timeout(300)
  H="#toast{visibility:hidden!important}"
  def go(r):
    pg.goto(u+'#'+r);pg.wait_for_timeout(500);pg.add_style_tag(content='.banner{display:none!important}');pg.wait_for_timeout(100)
  def hide(on):
    pg.evaluate("(on)=>{let s=document.getElementById('hidetoast');if(!s){s=document.createElement('style');s.id='hidetoast';document.head.append(s)}s.textContent=on?'#toast{visibility:hidden!important}':''}",on)
  def shot(n,toast=False):
    hide(not toast);pg.wait_for_timeout(80);pg.screenshot(path=f'cap/v-{n}.png')
  go('bank');shot('bank')
  pg.evaluate("toast('Profile saved')");pg.wait_for_timeout(400);shot('bank-toast',True)
  go('resume');pg.evaluate("S.resume.template='executive';S.resume.accent='ocean';save();render()");pg.wait_for_timeout(400);pg.add_style_tag(content='.banner{display:none!important}');shot('res-1')
  pg.click('[data-act="focus-design"][data-id="mint:teal:left"]');pg.wait_for_timeout(500);pg.add_style_tag(content='.banner{display:none!important}');shot('res-2')
  pg.click('[data-act="focus-design"][data-id="mint:mint:center"]');pg.wait_for_timeout(500);pg.add_style_tag(content='.banner{display:none!important}');shot('res-3')
  pg.evaluate("toast('Choose Save as PDF. Keep scale at 100%.')");pg.wait_for_timeout(400);shot('res-pdf-toast',True)
  go('jobs');shot('jobs')
  pg.evaluate("var a=S.applications.filter(function(x){return x.status==='Interviewing'})[0];a.status='Offer';save();render();toast('Moved to Offer')");pg.wait_for_timeout(400);pg.add_style_tag(content='.banner{display:none!important}');shot('jobs-moved',True)
  b.close()
