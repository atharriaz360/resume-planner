from playwright.sync_api import sync_playwright
import pathlib,datetime
u=pathlib.Path('app.html').resolve().as_uri()
with sync_playwright() as p:
  b=p.chromium.launch();pg=b.new_page(viewport={'width':1512,'height':982},device_scale_factor=2);pg.set_default_timeout(5000)
  pg.clock.install(time=datetime.datetime(2026,10,27,9,41))
  pg.goto(u+'#settings');pg.wait_for_timeout(500);pg.click('[data-act="sample"]');pg.wait_for_timeout(300)
  def go(r):
    pg.goto(u+'#'+r);pg.wait_for_timeout(600);pg.add_style_tag(content='.banner{display:none!important}');pg.wait_for_timeout(150)
  def shot(n): pg.screenshot(path=f'cap/v-{n}.png')
  go('bank');shot('bank')
  pg.evaluate("toast('Profile saved')");pg.wait_for_timeout(400);shot('bank-toast')
  go('resume')
  for t,a in [('mint','mint'),('executive','ocean'),('sidebar','amber'),('sidebar','ocean')]:
    pg.evaluate(f"S.resume.template='{t}';S.resume.accent='{a}';save();render()");pg.wait_for_timeout(400);pg.add_style_tag(content='.banner{display:none!important}');shot(f'res-{t}-{a}')
  pg.evaluate("toast('Choose Save as PDF. Keep scale at 100%.')");pg.wait_for_timeout(400);shot('res-pdf-toast')
  go('jobs');shot('jobs')
  pg.evaluate("var a=S.applications.filter(function(x){return x.status==='Interviewing'})[0];a.status='Offer';save();render();toast('Moved to Offer')");pg.wait_for_timeout(400);pg.add_style_tag(content='.banner{display:none!important}');shot('jobs-moved')
  # element positions for taps
  go('resume');print('dl',pg.eval_on_selector('[data-act="dl-pdf"]','e=>{const r=e.getBoundingClientRect();return [r.x+r.width/2,r.y+r.height/2]}'))
  go('bank');print('save',pg.evaluate("(()=>{const e=[...document.querySelectorAll('button')].find(b=>/Save profile/.test(b.textContent));const r=e.getBoundingClientRect();return [r.x+r.width/2,r.y+r.height/2]})()"))
  b.close()
