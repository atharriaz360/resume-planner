import sys,pathlib
from playwright.sync_api import sync_playwright
src=sys.argv[1];ids=sys.argv[2:]
with sync_playwright() as p:
  b=p.chromium.launch();pg=b.new_page(viewport={'width':1400,'height':1100},device_scale_factor=2)
  pg.goto(pathlib.Path(src).resolve().as_uri());pg.wait_for_timeout(800);pg.evaluate('document.fonts.ready')
  for i in ids: pg.locator('#'+i.split(':')[0]).screenshot(path=i.split(':')[1])
  b.close()
