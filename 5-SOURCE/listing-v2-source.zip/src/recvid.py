import sys,pathlib,os
from playwright.sync_api import sync_playwright
FPS=30;DUR=14.8;N=int(round(FPS*DUR))
os.makedirs('vframes',exist_ok=True)
a,b=int(sys.argv[1]),int(sys.argv[2])
with sync_playwright() as p:
  br=p.chromium.launch();pg=br.new_page(viewport={'width':1440,'height':1080})
  pg.goto(pathlib.Path('video.html').resolve().as_uri());pg.wait_for_timeout(1500);pg.evaluate('document.fonts.ready')
  for i in range(a,min(b,N)):
    pg.evaluate(f'setT({i/FPS})');pg.screenshot(path=f'vframes/{i:04d}.jpg',type='jpeg',quality=95)
  br.close()
print(N)
