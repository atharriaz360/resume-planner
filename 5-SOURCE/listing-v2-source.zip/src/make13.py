import cv2,numpy as np,comp,sys
bg=cv2.imread(comp.B+'13.jpg');H0,W0=bg.shape[:2]
BASE,S=comp.upscale(bg,seed=7)
PQ=[[540,985],[1050,1070],[962,1373],[388,1222]]
yy,xx=np.mgrid[0:H0,0:W0];EM=~(yy< 984+(xx-540)*0.256);EM[:955]=False
def make(lap,ph,paper,out):
  big,qs=comp.screens_into(BASE.copy(),bg,S,[lap,ph])
  if paper: big=comp.paper_into(big,bg,S,PQ,paper,thr=(110,38),extra_mask=EM)
  cv2.imwrite(out,big[620:2646],[cv2.IMWRITE_JPEG_QUALITY,93])
  return qs
jobs=[('vb','cap/v-bank.png','cap/ms-hub.png',None),('vbt','cap/v-bank-toast.png','cap/ms-hub.png',None),
('vr1','cap/v-res-1.png','cap/ms-hub.png',None),('vr2','cap/v-res-2.png','cap/ms-hub.png',None),
('vr3','cap/v-res-3.png','cap/ms-hub.png',None),('vj','cap/v-jobs.png','cap/ms-jobs.png',None),
('vjm','cap/v-jobs-moved.png','cap/ms-jobs.png',None),('vp','cap/v-res-pdf-toast.png','cap/ms-hub.png',None),
('vpp','cap/v-res-pdf-toast.png','cap/ms-hub.png','cap/q-mint-mint.png')]
for n,l,p,pa in jobs:
  qs=make(l,p,pa,f'scenes/{n}.jpg')
print([ (q).round().tolist() for q in qs])
