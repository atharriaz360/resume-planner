from playwright.sync_api import sync_playwright
import pathlib
from PIL import Image
u=pathlib.Path('app.html').resolve().as_uri()
with sync_playwright() as p:
  b=p.chromium.launch();pg=b.new_page(viewport={'width':1400,'height':3200},device_scale_factor=3);pg.set_default_timeout(5000)
  pg.goto(u+'#settings');pg.wait_for_timeout(400);pg.click('[data-act="sample"]');pg.wait_for_timeout(300)
  pg.goto(u+'#resume');pg.wait_for_timeout(500)
  for t in ['mint','executive','sidebar']:
    for a in ['mint','ocean','amber','teal']:
      pg.evaluate(f"S.resume.template='{t}';S.resume.accent='{a}';save();render()");pg.wait_for_timeout(300)
      pg.add_style_tag(content='.resume-edit,#paper button,.banner,#toast{display:none!important}#paper{box-shadow:none!important;outline:0!important}')
      pg.locator('#paper').screenshot(path=f'cap/q-{t}-{a}.png')
      im=Image.open(f'cap/q-{t}-{a}.png');w,h=im.size;im.crop((0,0,w,min(h,int(w*1.4142)))).save(f'cap/q-{t}-{a}.png')
  # cover letter paper
  pg.goto(u+'#cover');pg.wait_for_timeout(500)
  pg.add_style_tag(content='.resume-edit,#paper button,.banner,#toast{display:none!important}')
  pg.locator('#paper').screenshot(path='cap/q-cover.png')
  im=Image.open('cap/q-cover.png');w,h=im.size;im.crop((0,0,w,min(h,int(w*1.4142)))).save('cap/q-cover.png')
  b.close()
