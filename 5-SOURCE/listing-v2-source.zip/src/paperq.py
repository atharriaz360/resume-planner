import cv2,numpy as np,comp
for n in ['19','21','20','16']:
  im=cv2.imread(comp.B+n+'.jpg');f=im.astype(np.float32);mx=f.max(2);mn=f.min(2)
  m=((mx>200)&((mx-mn)<30)).astype(np.uint8)*255
  m=cv2.morphologyEx(m,cv2.MORPH_OPEN,np.ones((7,7),np.uint8))
  cs,_=cv2.findContours(m,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
  for c in sorted(cs,key=cv2.contourArea,reverse=True)[:3]:
    hull=cv2.convexHull(c);ap=cv2.approxPolyDP(hull,0.02*cv2.arcLength(hull,True),True).reshape(-1,2)
    print(n,int(cv2.contourArea(c)),cv2.boundingRect(c),ap.tolist())
