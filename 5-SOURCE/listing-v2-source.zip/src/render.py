import sys,pathlib
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
  b=p.chromium.launch();pg=b.new_page(viewport={'width':1350,'height':1013},device_scale_factor=2)
  for f in sys.argv[1:]:
    src,dst=f.split(':')
    pg.goto(pathlib.Path(src).resolve().as_uri());pg.wait_for_timeout(300);pg.evaluate('document.fonts.ready')
    pg.locator('.s').first.screenshot(path=dst)
  b.close()
