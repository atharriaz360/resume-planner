from playwright.sync_api import sync_playwright
import pathlib
u=pathlib.Path('app.html').resolve().as_uri()
with sync_playwright() as p:
  b=p.chromium.launch()
  pg=b.new_page(viewport={'width':1512,'height':945},device_scale_factor=2)
  errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
  pg.goto(u+'#settings');pg.wait_for_timeout(600)
  pg.click('[data-act="sample"]');pg.wait_for_timeout(500)
  for r in ['dashboard','hub','resume','cover','jobs','bank','contacts','playbook','settings']:
    pg.goto(u+'#'+r);pg.wait_for_timeout(700)
    pg.screenshot(path=f'cap/x-{r}.png')
  print(errs)
  print(pg.eval_on_selector_all('#nav a','els=>els.map(e=>e.getAttribute("href")+"|"+e.textContent.trim())'))
  b.close()
