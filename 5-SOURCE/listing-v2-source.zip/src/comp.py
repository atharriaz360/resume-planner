import cv2,numpy as np
from PIL import Image
B='/mnt/user-data/uploads/resume-planner-main/5-SOURCE/canva-bg/'
def greenness(img):
  f=img.astype(np.float32);b,g,r=f[...,0],f[...,1],f[...,2]
  return g-np.maximum(r,b)
def green_alpha(img,lo=18,hi=60):
  d=greenness(img);a=np.clip((d-lo)/(hi-lo),0,1)
  return cv2.GaussianBlur(a,(0,0),0.8)
def order(q):
  q=np.array(q,np.float32);c=q.mean(0)
  ang=np.arctan2(q[:,1]-c[1],q[:,0]-c[0]);q=q[np.argsort(ang)]
  # start at top-left (min x+y)
  i=np.argmin(q.sum(1));return np.roll(q,-i,0)
def refine_quad(mask,approx,W,H):
  # fit lines to contour points closest to each side
  cs,_=cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)
  c=max(cs,key=cv2.contourArea).reshape(-1,2).astype(np.float32)
  c=c[(c[:,0]>1)&(c[:,0]<W-2)&(c[:,1]>1)&(c[:,1]<H-2)]
  q=approx;lines=[]
  for i in range(4):
    p0,p1=q[i],q[(i+1)%4];v=p1-p0;L=np.linalg.norm(v);u=v/L;n=np.array([-u[1],u[0]])
    t=(c-p0)@u;d=np.abs((c-p0)@n)
    sel=(t>0.15*L)&(t<0.85*L)&(d<8)
    pts=c[sel]
    if len(pts)<10: lines.append((p0,u));continue
    vx,vy,x0,y0=cv2.fitLine(pts,cv2.DIST_HUBER,0,0.01,0.01).ravel()
    lines.append((np.array([x0,y0]),np.array([vx,vy])))
  out=[]
  for i in range(4):
    (a,da),(b,db)=lines[i-1],lines[i]
    A=np.array([da,-db]).T;t=np.linalg.solve(A,b-a);out.append(a+t[0]*da)
  return np.array(out,np.float32)
def find_screens(img,min_area=3000,lo=35):
  H,W=img.shape[:2];d=greenness(img)
  m=(d>lo).astype(np.uint8)*255
  m=cv2.morphologyEx(m,cv2.MORPH_OPEN,np.ones((5,5),np.uint8))
  cs,_=cv2.findContours(m,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
  res=[]
  for c in sorted(cs,key=cv2.contourArea,reverse=True):
    if cv2.contourArea(c)<min_area: continue
    hull=cv2.convexHull(c);peri=cv2.arcLength(hull,True)
    for eps in [0.02,0.03,0.04,0.015,0.05]:
      ap=cv2.approxPolyDP(hull,eps*peri,True).reshape(-1,2)
      if len(ap)==4:break
    if len(ap)!=4: continue
    q=order(ap);one=np.zeros_like(m);cv2.drawContours(one,[c],-1,255,-1)
    res.append(refine_quad(one,q,W,H))
  return res
def warp(src,quad,W,H):
  h,w=src.shape[:2]
  M=cv2.getPerspectiveTransform(np.float32([[0,0],[w,0],[w,h],[0,h]]),np.float32(quad))
  out=cv2.warpPerspective(src,M,(W,H),flags=cv2.INTER_AREA if w>W else cv2.INTER_CUBIC,borderMode=cv2.BORDER_CONSTANT,borderValue=(0,0,0,0))
  return out
def prep_src(path,w=None):
  im=cv2.imread(path,cv2.IMREAD_UNCHANGED)
  if im.shape[2]==3: im=cv2.cvtColor(im,cv2.COLOR_BGR2BGRA)
  return im
def supersample_warp(src,quad,W,H,ss=1):
  # downscale src first to approx target size to reduce aliasing
  q=np.array(quad);tw=max(np.linalg.norm(q[1]-q[0]),np.linalg.norm(q[2]-q[3]));th=max(np.linalg.norm(q[3]-q[0]),np.linalg.norm(q[2]-q[1]))
  h,w=src.shape[:2];s=min(1,max(tw/w,th/h)*1.6)
  if s<1: src=cv2.resize(src,(int(w*s),int(h*s)),interpolation=cv2.INTER_AREA)
  return warp(src,quad,W,H)
def screen_into(bg,quad,src,key_alpha=None,bright=1.0,glare=0.06,warm=(1,1,1)):
  H,W=bg.shape[:2];wp=supersample_warp(src,quad,W,H).astype(np.float32)
  a_src=wp[...,3:4]/255.0
  rgb=wp[...,:3]*bright*np.array(warm[::-1],np.float32)
  # glare: diagonal soft gradient
  q=np.array(quad);yy,xx=np.mgrid[0:H,0:W].astype(np.float32)
  p0=q[0];v=q[2]-q[0];t=((xx-p0[0])*v[0]+(yy-p0[1])*v[1])/(v@v)
  g=np.clip(1-np.abs(t-0.25)/0.35,0,1)**2*glare*255
  rgb=np.clip(rgb+g[...,None],0,255)
  a=a_src if key_alpha is None else a_src*key_alpha[...,None]
  out=bg.astype(np.float32)
  # spill suppress where keyed partially
  if key_alpha is not None:
    o=out;mx=np.maximum(o[...,0],o[...,2]);gch=o[...,1];edge=(key_alpha>0.02)
    o[...,1]=np.where(edge,np.minimum(gch,mx*1.02),gch)
  out=out*(1-a)+rgb*a
  return np.clip(out,0,255).astype(np.uint8)

def upscale(bg,W=2700,grain=1.6,seed=7):
  H=int(round(bg.shape[0]*W/bg.shape[1]))
  big=cv2.resize(bg,(W,H),interpolation=cv2.INTER_LANCZOS4)
  bl=cv2.GaussianBlur(big,(0,0),2.0);big=cv2.addWeighted(big,1.25,bl,-0.25,0)
  rng=np.random.default_rng(seed);gr=rng.normal(0,3.2,(H,W)).astype(np.float32);gr=cv2.GaussianBlur(gr,(0,0),0.6)
  return np.clip(big.astype(np.float32)+gr[...,None]*grain,0,255).astype(np.uint8),W/bg.shape[1]
def paper_into(big,bg,S,quad,src,thr=(110,38),ymin=0,extra_mask=None,pad_top=0.0,ink_floor=0.12,bright=1.04):
  H0,W0=bg.shape[:2];H,W=big.shape[:2]
  f=bg.astype(np.float32);mx=f.max(2);mn=f.min(2)
  m=((mx>thr[0])&((mx-mn)<thr[1])).astype(np.uint8)*255;m[:ymin]=0
  if extra_mask is not None: m[~extra_mask]=0
  m=cv2.morphologyEx(m,cv2.MORPH_OPEN,np.ones((3,3),np.uint8))
  m=cv2.resize(m,(W,H),interpolation=cv2.INTER_LINEAR).astype(np.float32)/255
  m=cv2.GaussianBlur(m,(0,0),1.0)
  res=prep_src(src) if isinstance(src,str) else src
  if pad_top: h=res.shape[0];res=cv2.copyMakeBorder(res,int(h*pad_top),0,0,0,cv2.BORDER_CONSTANT,value=(255,255,255,255))
  wp=supersample_warp(res,np.float32(quad)*S,W,H).astype(np.float32)
  a=(wp[...,3]/255)*m
  shade=cv2.GaussianBlur(big.astype(np.float32),(0,0),9)/255.0
  wr=cv2.GaussianBlur(wp[...,:3],(0,0),0.7)/255.0;wr=ink_floor+(1-ink_floor)*wr
  ink=wr*shade*255*bright
  o=big.astype(np.float32)*(1-a[...,None])+ink*a[...,None]
  return np.clip(o,0,255).astype(np.uint8)
def screens_into(big,bg,S,srcs,bright=0.97,glare=0.05,order_override=None):
  qs=find_screens(bg);out=big;d=greenness(big)
  if order_override: qs=[qs[i] for i in order_override]
  for q,s in zip(qs,srcs):
    if s is None: continue
    m=np.zeros(d.shape,np.uint8);cv2.fillPoly(m,[(q*S).astype(np.int32)],1);m=cv2.erode(m,np.ones((15,15)))
    med=np.median(d[m>0]);ka=green_alpha(big,lo=0.3*med,hi=0.72*med)
    out=screen_into(out,q*S,prep_src(s),ka,bright=bright,glare=glare)
  return out,[q*S for q in qs]
