import cv2,numpy as np,sys,json
B='/mnt/user-data/uploads/resume-planner-main/5-SOURCE/canva-bg/'
out={}
for n in ['13','18','20','21','22']:
  im=cv2.imread(B+n+'.jpg').astype(int);b,g,r=im[...,0],im[...,1],im[...,2]
  m=((g>r+35)&(g>b+20)).astype(np.uint8)*255
  m=cv2.morphologyEx(m,cv2.MORPH_OPEN,np.ones((5,5),np.uint8))
  cs,_=cv2.findContours(m,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
  cs=sorted(cs,key=cv2.contourArea,reverse=True)[:3]
  res=[]
  for c in cs:
    a=cv2.contourArea(c)
    if a<3000: continue
    hull=cv2.convexHull(c);peri=cv2.arcLength(hull,True)
    ap=cv2.approxPolyDP(hull,0.02*peri,True).reshape(-1,2).tolist()
    res.append({'area':a,'quad':ap,'bbox':cv2.boundingRect(c)})
  out[n]=res;print(n,res)
json.dump(out,open('quads.json','w'))
