import cv2,sys
n,x0,y0,x1,y1=map(int,sys.argv[1:6]);out=sys.argv[6]
im=cv2.imread(f'bg/{n}.jpg')[y0:y1,x0:x1].copy()
s=900/max(im.shape[:2]);im=cv2.resize(im,None,fx=s,fy=s)
step=50
for x in range((x0//step+1)*step,x1,step):
    X=int((x-x0)*s);cv2.line(im,(X,0),(X,im.shape[0]),(0,0,255) if x%100==0 else (0,180,255),1)
    if x%100==0: cv2.putText(im,str(x),(X+2,14),0,.45,(0,0,255),1)
for y in range((y0//step+1)*step,y1,step):
    Y=int((y-y0)*s);cv2.line(im,(0,Y),(im.shape[1],Y),(0,0,255) if y%100==0 else (0,180,255),1)
    if y%100==0: cv2.putText(im,str(y),(2,Y-2),0,.45,(0,0,255),1)
cv2.imwrite(out,im)
