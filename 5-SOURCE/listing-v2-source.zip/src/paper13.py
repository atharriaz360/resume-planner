import cv2,numpy as np
im=cv2.imread('/mnt/user-data/uploads/resume-planner-main/5-SOURCE/canva-bg/13.jpg')
f=im.astype(np.float32);mx=f.max(2);mn=f.min(2)
m=((mx>120)&((mx-mn)<35)).astype(np.uint8)*255
m[:960]=0
m=cv2.morphologyEx(m,cv2.MORPH_OPEN,np.ones((5,5),np.uint8))
cs,_=cv2.findContours(m,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_NONE)
c=max(cs,key=cv2.contourArea);print(cv2.contourArea(c),cv2.boundingRect(c))
pts=c.reshape(-1,2)
# left edge: leftmost pixel per row; right edge: rightmost per row
for y in [1000,1020,1060,1100,1150,1200,1250,1262]:
  xs=pts[pts[:,1]==y][:,0];print(y,xs.min() if len(xs) else None,xs.max() if len(xs) else None)
cv2.imwrite('prev/papermask.png',m)
print(f[1150,700],f[1100,950])
