import cv2,numpy as np,comp,sys
S=2700/1264
bg=cv2.imread(comp.B+'13.jpg');H0,W0=bg.shape[:2]
big=cv2.resize(bg,(2700,2700),interpolation=cv2.INTER_LANCZOS4)
# mild unsharp to offset upscale softness
bl=cv2.GaussianBlur(big,(0,0),2.0);big=cv2.addWeighted(big,1.25,bl,-0.25,0)
rng=np.random.default_rng(7);gr=rng.normal(0,3.2,(2700,2700,1)).astype(np.float32);gr=cv2.GaussianBlur(gr,(0,0),0.6)[...,None]
big=np.clip(big.astype(np.float32)+gr*1.6,0,255).astype(np.uint8)
qs=comp.find_screens(bg)
lap,phn=qs[0]*S,qs[1]*S
ka=comp.green_alpha(big)
lapsrc=comp.prep_src(sys.argv[1] if len(sys.argv)>1 else 'cap/d-resume.png')
phsrc=comp.prep_src(sys.argv[2] if len(sys.argv)>2 else 'cap/ms-hub.png')
out=comp.screen_into(big,lap,lapsrc,ka,bright=0.97,glare=0.05)
out=comp.screen_into(out,phn,phsrc,ka,bright=0.95,glare=0.07)
# paper: resume
f=bg.astype(np.float32);mx=f.max(2);mn=f.min(2)
m=((mx>110)&((mx-mn)<38)).astype(np.uint8)*255;m[:955]=0
yy,xx=np.mgrid[0:H0,0:W0]
m[yy< 984+(xx-540)*0.256]=0
m=cv2.morphologyEx(m,cv2.MORPH_OPEN,np.ones((5,5),np.uint8))
m=cv2.resize(m,(2700,2700),interpolation=cv2.INTER_LINEAR).astype(np.float32)/255
m=cv2.GaussianBlur(m,(0,0),1.2)
pq=np.float32([[540,985],[1050,1070],[962,1373],[388,1222]])*S
res=comp.prep_src(sys.argv[3] if len(sys.argv)>3 else 'cap/q-sidebar-ocean.png')
h,w=res.shape[:2];pad=int(h*0.07);res=cv2.copyMakeBorder(res,pad,0,0,0,cv2.BORDER_CONSTANT,value=(255,255,255,255))
wp=comp.supersample_warp(res,pq,2700,2700).astype(np.float32)
a=(wp[...,3]/255)*m
paper=cv2.GaussianBlur(big.astype(np.float32),(0,0),9)
shade=paper/255.0
wr=cv2.GaussianBlur(wp[...,:3],(0,0),0.7)/255.0
wr=0.12+0.88*wr
ink=wr*shade*255*1.04
o=out.astype(np.float32);o=o*(1-a[...,None])+ink*a[...,None]
out=np.clip(o,0,255).astype(np.uint8)
cv2.imwrite(sys.argv[4] if len(sys.argv)>4 else 'scenes/s13-full.png',out)
print(lap.round().tolist(),phn.round().tolist())
