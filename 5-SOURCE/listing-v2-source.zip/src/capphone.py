from playwright.sync_api import sync_playwright
import pathlib,datetime
u=pathlib.Path('app.html').resolve().as_uri()
CSS='.banner{display:none!important}#toast{display:none!important}'
SB='''<!doctype html><html><head><style>*{margin:0;padding:0}body{width:393px;height:852px;background:%s;font-family:Inter;overflow:hidden}
.sb{height:54px;display:flex;align-items:center;justify-content:space-between;padding:0 32px 0 46px;font:600 17px Inter;color:#111;letter-spacing:-.01em}
.ic{display:flex;gap:6px;align-items:center}img{display:block;width:393px}</style></head><body>
<div class="sb"><span>9:41</span><span class="ic">
<svg width="18" height="12" viewBox="0 0 18 12"><rect x="0" y="8" width="3" height="4" rx="1"/><rect x="5" y="5.5" width="3" height="6.5" rx="1"/><rect x="10" y="3" width="3" height="9" rx="1"/><rect x="15" y="0" width="3" height="12" rx="1"/></svg>
<svg width="16" height="12" viewBox="0 0 16 12"><path d="M8 2.6c2.2 0 4.2.9 5.7 2.3l1.1-1.1C13 2 10.6 1 8 1S3 2 1.2 3.8l1.1 1.1C3.8 3.5 5.8 2.6 8 2.6zm0 3.3c1.3 0 2.5.5 3.4 1.3l1.1-1.1C11.3 5 9.7 4.3 8 4.3S4.7 5 3.5 6.1l1.1 1.1C5.5 6.4 6.7 5.9 8 5.9zm0 3.2c.5 0 .9.2 1.2.5L8 10.8 6.8 9.6c.3-.3.7-.5 1.2-.5z"/></svg>
<svg width="27" height="13" viewBox="0 0 27 13"><rect x=".5" y=".5" width="23" height="12" rx="3.5" fill="none" stroke="#111" opacity=".4"/><rect x="2" y="2" width="20" height="9" rx="2"/><path d="M25 4.5v4c.8-.3 1.3-1.1 1.3-2s-.5-1.7-1.3-2z" opacity=".5"/></svg>
</span></div><img src="%s"></body></html>'''
with sync_playwright() as p:
  b=p.chromium.launch()
  ph=b.new_page(viewport={'width':393,'height':798},device_scale_factor=3,is_mobile=True,has_touch=True);ph.set_default_timeout(5000)
  ph.clock.install(time=datetime.datetime(2026,10,27,9,41))
  ph.goto(u+'#settings');ph.wait_for_timeout(500);ph.click('[data-act="sample"]');ph.wait_for_timeout(300)
  bgc=None
  for r in ['hub','resume','cover','jobs','bank']:
    ph.goto(u+'#'+r);ph.wait_for_timeout(600);ph.add_style_tag(content=CSS);ph.wait_for_timeout(200)
    ph.screenshot(path=f'cap/mr-{r}.png')
    bgc=ph.evaluate("getComputedStyle(document.body).backgroundColor")
    w=b.new_page(viewport={'width':393,'height':852},device_scale_factor=3)
    open('sb.html','w').write(SB%(bgc,pathlib.Path(f'cap/mr-{r}.png').resolve().as_uri()))
    w.goto(pathlib.Path('sb.html').resolve().as_uri());w.wait_for_timeout(150);w.screenshot(path=f'cap/ms-{r}.png');w.close()
  print(bgc)
  b.close()
